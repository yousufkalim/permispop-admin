import React, { useState, useEffect, useMemo } from "react";
import WebServicesManager from "../../WebServicesManager/WebServicesManager";
import InstructorAdd from "../InstructorComponents/InstructorAdd";
import { Translation } from "react-i18next";

function UserInstructors(props) {
  const WebServicesManagers = useMemo(() => new WebServicesManager(), []);
  const [instructors, setInstructors] = useState([]);
  const [updateList, setUpdateList] = useState(false);
  const [showAdd, setShowAdd] = useState(false);

  // fetch all instructors by driving school
  useEffect(() => {
    // console.log(props, "Props");
    var tokn = localStorage.getItem("userdata");
    console.log("instructor component mount");

    WebServicesManagers.getApiWithParamCall(
      {
        endPoint: "Profile/GetProfileByPersonalId",
        dataToFetch: props.id,
        token: tokn,
      },
      (statusCode, responseDrivingSchool) => {
        var instructorsDetails = JSON.parse(
          responseDrivingSchool.drivingSchoolInstructorInfoId
        );
        var lenToMatch = Object.entries(instructorsDetails).length;
        var data = [];
        Object.entries(instructorsDetails).forEach(async ([key, value]) => {
          if (value !== null && value !== undefined) {
            // inslen = inslen + 1;
            await WebServicesManagers.getApiWithParamCall(
              {
                endPoint: "Personal/GetAllById",
                dataToFetch: value,
                token: tokn,
              },
              (statusCode, responsePersonalData) => {
                var datais = [
                  `${responsePersonalData.firstName} ${responsePersonalData.surName}`,
                  `${responsePersonalData.address} ${responsePersonalData.zip} ${responsePersonalData.city}`,
                  responsePersonalData.gender,
                  responsePersonalData.email,
                  responsePersonalData.documentTested,
                  responsePersonalData.id,
                ];
                data.push(datais);
                if (data.length === lenToMatch) {
                  setInstructors(data);
                }
              }
            );
          } else {
            lenToMatch = lenToMatch - 1;
            if (data.length === lenToMatch) {
              setInstructors(data);
            }
          }
        });
      }
    );
    // eslint-disable-next-line
  }, [updateList]);

  const updateData = () => {
    setUpdateList(!updateList);
  };
  const showModal = () => {
    if (showAdd === true) {
      setShowAdd(false);
    } else {
      setShowAdd(true);
    }
    console.log();
  };
  return (
    <Translation>
      {(t) => (
        <div className="table-responsive" style={{ overflowX: "scroll" }}>
          <i
            title="Add Instructor"
            className="fa fa-plus-circle"
            style={{ float: "right", fontSize: 18, margin: "15px 10px" }}
            onClick={() => showModal()}
          ></i>
          <InstructorAdd
            showAddModel={showAdd}
            drivingSchoolData={props}
            update={updateData}
          />
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>{t("Name")}</th>
                <th>{t("Address")}</th>
                <th>{t("Gender")}</th>
                <th>{t("Email")}</th>
                <th>{t("Status")}</th>
                <th>{t("Actions")}</th>
              </tr>
            </thead>
            <tbody>
              {instructors.length > 0
                ? instructors.map((ins) => (
                    <tr key={ins[ins.length - 1]}>
                      <td>{ins[0]}</td>
                      <td>{ins[1]}</td>
                      <td>{ins[2]}</td>
                      <td>{ins[3]}</td>
                      <td>
                        {ins[4] === "Tested" ? (
                          <i
                            className="fa fa-check"
                            style={{ color: "green" }}
                          ></i>
                        ) : (
                          <i
                            className="fa fa-times"
                            style={{ color: "red" }}
                          ></i>
                        )}
                      </td>
                      <td>
                        <i
                          className="fa fa-eye"
                          onClick={() => props.changeUser(ins[5])}
                        ></i>
                        {/* <i className="fa fa-trash"></i> */}
                      </td>
                    </tr>
                  ))
                : ""}
            </tbody>
          </table>
        </div>
      )}
    </Translation>
  );
}

export default UserInstructors;
